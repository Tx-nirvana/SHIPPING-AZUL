const DEFAULT_MINUTES=1;
async function schedule(){const s=await chrome.storage.local.get({intervalMinutes:DEFAULT_MINUTES});chrome.alarms.create('spxSync',{periodInMinutes:Number(s.intervalMinutes)||DEFAULT_MINUTES});}
chrome.runtime.onInstalled.addListener(async()=>{await chrome.storage.local.set({intervalMinutes:DEFAULT_MINUTES});await schedule();});
chrome.runtime.onStartup.addListener(schedule);
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.intervalMinutes) schedule();});
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  if(msg?.type==='CAPTURE_ACTIVE'){
    chrome.tabs.query({active:true,currentWindow:true}).then(async tabs=>{
      const tab=tabs[0]; if(!tab?.id || !String(tab.url||'').startsWith('https://spx.shopee.com.br/')){sendResponse({ok:false,error:'Abra a página de viagens do SPX no Opera.'});return;}
      try{await chrome.tabs.sendMessage(tab.id,{type:'SPX_CAPTURE'});sendResponse({ok:true});}
      catch{try{await chrome.scripting.executeScript({target:{tabId:tab.id},files:['content.js']});sendResponse({ok:true});}catch(e){sendResponse({ok:false,error:e.message});}}
    });
    return true;
  }
});
chrome.alarms.onAlarm.addListener(async alarm=>{
  if(alarm.name!=='spxSync')return;
  const tabs=await chrome.tabs.query({url:['https://spx.shopee.com.br/*']});
  for(const tab of tabs){
    try{await chrome.tabs.sendMessage(tab.id,{type:'SPX_CAPTURE'});}
    catch{try{await chrome.scripting.executeScript({target:{tabId:tab.id},files:['content.js']});}catch{}}
  }
});
