@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
color 0B
cls
echo ================================================================
echo          SHIPPING AZUL - INICIADOR AUTOMATICO V4
echo ================================================================
echo.
where node >nul 2>&1
if errorlevel 1 (
  echo [ERRO] Node.js nao encontrado.
  echo Instale Node.js LTS e execute novamente.
  pause
  exit /b 1
)
if not exist "%~dp0spx-bridge\package.json" (
  echo [ERRO] Pasta spx-bridge nao encontrada.
  pause
  exit /b 1
)
cd /d "%~dp0spx-bridge"
if not exist "node_modules\express" (
  echo [1/5] Instalando dependencias...
  call npm.cmd install
  if errorlevel 1 (
    echo [ERRO] npm install falhou.
    pause
    exit /b 1
  )
) else echo [1/5] Dependencias OK.
echo [2/5] Iniciando bridge...
start "Shipping Azul - Bridge SPX" cmd /k "cd /d "%~dp0spx-bridge" && npm.cmd start"
echo [3/5] Aguardando bridge...
set READY=0
for /l %%i in (1,1,20) do (
  timeout /t 1 /nobreak >nul
  curl.exe -s http://127.0.0.1:8787/health >nul 2>&1
  if not errorlevel 1 (set READY=1&goto :bridge_ok)
)
:bridge_ok
if "%READY%"=="0" echo [AVISO] Bridge demorou a responder. Confira a janela dela.
if "%READY%"=="1" echo [OK] Bridge online.
cd /d "%~dp0"
echo [4/5] Abrindo o sistema no Opera...
set "OPERA="
for %%P in ("%LOCALAPPDATA%\Programs\Opera\launcher.exe" "%LOCALAPPDATA%\Programs\Opera GX\launcher.exe" "%PROGRAMFILES%\Opera\launcher.exe" "%PROGRAMFILES(x86)%\Opera\launcher.exe") do if not defined OPERA if exist "%%~P" set "OPERA=%%~P"
if defined OPERA (
  start "" "%OPERA%" "file:///%~dp0index.html"
  timeout /t 2 /nobreak >nul
  start "" "%OPERA%" "opera://extensions"
) else start "" "%~dp0index.html"
echo.
echo [5/5] Sistema aberto.
echo.
echo PRIMEIRA VEZ: carregue a pasta spx-extension em opera://extensions

echo Depois disso, basta executar este BAT.
echo.
pause
