const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 8787);
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'spx-trips.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
app.use(cors({ origin: true }));
app.use(express.json({ limit: '2mb' }));

let state = { connected:false, updatedAt:null, trips:[], source:'opera-extension' };
let debugState={at:null,url:'',title:'',bodyText:'',headers:[],captureCount:0};

try { if (fs.existsSync(DATA_FILE)) { const x=JSON.parse(fs.readFileSync(DATA_FILE,'utf8')); if(x&&Array.isArray(x.trips)) state=x; } } catch(e) { console.warn('[SPX] Não foi possível ler o cache:',e.message); }

app.get('/api/status', (_req,res)=>res.json({ok:true, ...state, count:state.trips.length}));
app.get('/api/spx/trips', (_req,res)=>res.json({success:true, ...state, count:state.trips.length}));
app.post('/api/spx/trips', (req,res)=>{
  const trips = Array.isArray(req.body?.trips) ? req.body.trips : [];
  const now=new Date().toISOString();
  // Never erase the last good capture just because a SPA render momentarily returned zero rows.
  if(trips.length===0 && Array.isArray(state.trips) && state.trips.length){
    state={...state,connected:true,lastCaptureAt:now};
  }else{
    state={...state,connected:true,updatedAt:now,lastCaptureAt:now,trips,source:'opera-extension'};
    if(trips.length)state.lastNonEmptyAt=now;
  }
  try { fs.writeFileSync(DATA_FILE, JSON.stringify(state,null,2),'utf8'); } catch(e) { console.warn('[SPX] Falha ao salvar cache:',e.message); }
  console.log(`[SPX] ${trips.length} viagem(ns) recebida(s) em ${new Date().toLocaleString('pt-BR')}${trips.length===0?' — mantendo último snapshot':''}`);
  res.json({success:true,count:state.trips.length,received:trips.length,updatedAt:state.updatedAt||now,lastCaptureAt:state.lastCaptureAt});
});
app.post('/api/spx/debug', (req,res)=>{ debugState={at:new Date().toISOString(),url:String(req.body?.url||''),title:String(req.body?.title||''),bodyText:String(req.body?.bodyText||'').slice(0,20000),headers:Array.isArray(req.body?.headers)?req.body.headers.slice(0,80):[],captureCount:Number(req.body?.captureCount||0)}; console.log(`[SPX DEBUG] captura vazia em ${new Date().toLocaleString('pt-BR')} — ${debugState.title}`); res.json({success:true}); });
app.get('/api/spx/debug', (_req,res)=>res.json({success:true,...debugState}));
app.post('/api/spx/disconnected', (_req,res)=>{ state.connected=false; res.json({success:true}); });
app.get('/health', (_req,res)=>res.json({ok:true}));
app.listen(PORT,'127.0.0.1',()=>console.log(`[API] SPX Bridge em http://127.0.0.1:${PORT}`));
