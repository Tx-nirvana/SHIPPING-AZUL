SPX Bridge

1) Instale Node.js.
2) Abra o terminal nesta pasta e execute: npm install
3) Execute: npm start
4) A API ficará em http://127.0.0.1:8787

O servidor NÃO armazena login ou senha do SPX. A extensão captura a página que já está aberta e envia somente os dados da tabela para este servidor local.
