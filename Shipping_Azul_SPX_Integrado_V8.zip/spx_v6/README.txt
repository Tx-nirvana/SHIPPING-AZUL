SHIPPING AZUL + SPX V4

O V4 integra as viagens do SPX diretamente no Histórico de Carregamentos.
Não cria uma tabela separada de SPX.

FLUXO:
SPX no Opera -> extensão -> Bridge local -> Histórico de Carregamentos

1) Primeira vez:
- Execute INICIAR_SHIPPING_AZUL.bat
- Ele verifica Node.js, instala dependências se necessário, inicia a bridge e abre o sistema.
- No Opera, abra opera://extensions, ative o Modo desenvolvedor e use "Carregar descompactada".
- Selecione a pasta spx-extension dentro desta pasta.

2) Depois:
- Basta executar INICIAR_SHIPPING_AZUL.bat.
- O bridge inicia sozinho.
- Abra o SPX no Opera e deixe a tela de Hub Linehaul Trips / Trip aberta.
- A extensão captura automaticamente e envia para o Histórico.

MAPEAMENTO:
Número do LH -> LT / Pedido
Destino do Pedido Pretendido -> Destino
Motorista -> Motorista
Placa do Veículo -> Placa
Veículo -> Tipo de veículo
Docas de Saída -> Doca
ATA -> Chegada
ATD -> Fim / Liberação
STA/STD/ETA/ETD/Station/Pontualidade/Última localização -> Observações

O mesmo LH é atualizado em vez de ser duplicado.
A bridge também preserva o último snapshot válido se uma renderização do SPX retornar temporariamente 0 linhas.

Se a extensão ainda não conseguir capturar, o bridge guarda um diagnóstico em:
http://127.0.0.1:8787/api/spx/debug
