(() => {
  if (window.__shippingAzulSPXCollectorV4) return;
  window.__shippingAzulSPXCollectorV4 = true;

  const ENDPOINT = 'http://127.0.0.1:8787/api/spx/trips';
  const DEBUG_ENDPOINT = 'http://127.0.0.1:8787/api/spx/debug';
  const aliases = {
    numeroLH: ['número do lh','numero do lh','numero lh','lh number','lh no'],
    nomeViagem: ['nome da viagem','nome viagem','trip name'],
    ultimaAtualizacaoLocalizacao: ['última atualização de localização','ultima atualização de localização','ultima atualizacao de localizacao','last location update','last update'],
    station: ['station'],
    indicadorPontualidade: ['indicador de pontualidade','pontualidade','on time','timeliness'],
    veiculo: ['veículo','veiculo','vehicle'],
    placa: ['placa do veículo','placa do veiculo','placa de veículo','vehicle plate'],
    motorista: ['motorista','driver'],
    destino: ['destino do pedido pretendido','destino do pedido','destino'],
    doca: ['docas de saída','doca de saída','doca','departure dock'],
    combinedSTA: ['sta std','sta/std','sta\nstd'],
    combinedATA: ['ata atd','ata/atd','ata\natd'],
    combinedETA: ['eta etd','eta/etd','eta\netd'],
    dataPartidaPrevista: ['data de partida prevista','partida prevista','planned departure date'],
    STA: ['sta'], STD: ['std'], ATA: ['ata'], ATD: ['atd'], ETA: ['eta'], ETD: ['etd']
  };
  const desiredKeys = ['numeroLH','nomeViagem','ultimaAtualizacaoLocalizacao','station','indicadorPontualidade','veiculo','STA','STD','ATA','ATD','dataPartidaPrevista','ETA','ETD','placa','motorista','destino','doca'];

  const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
  const clean = s => String(s ?? '').replace(/[\u200B-\u200D\uFEFF]/g,'').replace(/[\r\n\t]+/g,' ').replace(/\s{2,}/g,' ').trim();
  const visible = el => { try { const r=el.getBoundingClientRect(); const st=getComputedStyle(el); return !!r.width&&!!r.height&&st.display!=='none'&&st.visibility!=='hidden'&&st.opacity!=='0'; } catch { return false; } };

  function matchKey(h) {
    const n = norm(h);
    for (const k of ['combinedSTA','combinedATA','combinedETA']) {
      if (aliases[k].some(a => n === norm(a) || n.includes(norm(a)))) return k;
    }
    for (const [key,arr] of Object.entries(aliases)) {
      if (['combinedSTA','combinedATA','combinedETA'].includes(key)) continue;
      if (arr.some(a => n === norm(a))) return key;
    }
    for (const [key,arr] of Object.entries(aliases)) {
      if (['combinedSTA','combinedATA','combinedETA'].includes(key)) continue;
      if (arr.some(a => n.includes(norm(a)))) return key;
    }
    return null;
  }

  function normalize(o) {
    const r={}; for (const k of desiredKeys) r[k]=clean(o[k] || ''); return r;
  }

  function splitPair(value) {
    const s=clean(value); if(!s) return ['',''];
    let p=s.split(/\s+\/\s+|\s*\n\s*|\s{3,}/).map(clean).filter(Boolean);
    if(p.length>=2) return [p[0],p.slice(1).join(' / ')];
    const m=s.match(/(\d{1,2}[-/]\d{1,2}(?:[-/]\d{2,4})?\s+\d{1,2}:\d{2}).*?(\d{1,2}[-/]\d{1,2}(?:[-/]\d{2,4})?\s+\d{1,2}:\d{2})/);
    return m?[m[1],m[2]]:[s,''];
  }

  function finish(o){
    const r=normalize(o);
    const a=splitPair(o.combinedSTA||''); if(!r.STA)r.STA=a[0]; if(!r.STD)r.STD=a[1];
    const b=splitPair(o.combinedATA||''); if(!r.ATA)r.ATA=b[0]; if(!r.ATD)r.ATD=b[1];
    const c=splitPair(o.combinedETA||''); if(!r.ETA)r.ETA=c[0]; if(!r.ETD)r.ETD=c[1];
    return r;
  }

  // Strategy 1: common table/grid implementations used by Vue/React libraries.
  function rowsFromKnownGrids(){
    const rowSelectors=[
      '.ant-table-tbody > tr', '.ant-table-row', '.el-table__body-wrapper tbody tr', '.el-table__body tbody tr',
      '.MuiDataGrid-row', '.ag-center-cols-container .ag-row', '.q-table tbody tr',
      '[role="row"]', '[data-row-key]', '[class*="table-row"]', '[class*="table_row"]', '[class*="grid-row"]', '[class*="grid_row"]'
    ];
    const out=[];
    for(const sel of rowSelectors){
      const rows=[...document.querySelectorAll(sel)].filter(visible);
      if(rows.length<2) continue;
      const headerCandidates=[...document.querySelectorAll('th,[role="columnheader"],[class*="header-cell"],[class*="table-header"],[class*="grid-header"]')].filter(visible);
      let headers=headerCandidates.map(el=>({el,text:clean(el.innerText),r:el.getBoundingClientRect()})).filter(x=>matchKey(x.text));
      if(headers.length<3) continue;
      const cols=headers.map(x=>({key:matchKey(x.text),x:x.r.left+x.r.width/2}));
      const mapped=rows.map(row=>{
        const rr=row.getBoundingClientRect();
        const cells=[...row.querySelectorAll('td,[role="gridcell"],[role="cell"]'),
          ...row.children].filter(Boolean).filter(visible);
        const uniq=[]; const seen=new Set();
        for(const c of cells){const r=c.getBoundingClientRect();const id=`${Math.round(r.left)}|${Math.round(r.top)}|${clean(c.innerText)}`;if(!seen.has(id)){seen.add(id);uniq.push(c);}}
        const o={};
        for(const c of uniq){const r=c.getBoundingClientRect(),cx=r.left+r.width/2;let best=null,bd=Infinity;for(const col of cols){const d=Math.abs(cx-col.x);if(d<bd){bd=d;best=col;}}if(best&&bd<Math.max(140,rr.width*0.16)){o[best.key]=(o[best.key]?o[best.key]+'\n':'')+clean(c.innerText);}}
        return finish(o);
      }).filter(x=>x.numeroLH||x.nomeViagem);
      if(mapped.length) out.push(...mapped);
      if(out.length>=1) break;
    }
    return dedupe(out);
  }

  // Strategy 2: locate exact header texts, then use geometry to reconstruct each row.
  function rowsFromGeometry(){
    const all=[...document.querySelectorAll('body *')].filter(visible);
    const rawHeaders=[];
    for(const el of all){
      const text=clean(el.childElementCount?el.innerText:el.textContent);
      if(!text||text.length>80)continue;
      const key=matchKey(text); if(!key)continue;
      const r=el.getBoundingClientRect();
      if(r.top>Math.min(window.innerHeight*.45,320))continue;
      rawHeaders.push({key,x:r.left+r.width/2,top:r.top,bottom:r.bottom,w:r.width,h:r.height,area:r.width*r.height,el});
    }
    const byKey=new Map();
    for(const h of rawHeaders){const old=byKey.get(h.key);if(!old||h.area<old.area)byKey.set(h.key,h);}
    let cols=[...byKey.values()].sort((a,b)=>a.x-b.x);
    if(cols.length<6) return [];
    cols=cols.filter((c,i)=>i===0||Math.abs(c.x-cols[i-1].x)>14);
    const lh=cols.find(c=>c.key==='numeroLH'); if(!lh)return [];
    const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
    const atoms=[];
    while(walker.nextNode()){
      const node=walker.currentNode, t=clean(node.nodeValue||''); if(!t)continue;
      const p=node.parentElement;if(!p||!visible(p))continue;
      const r=p.getBoundingClientRect(); if(r.top<=lh.bottom+3||r.top>window.innerHeight+100)continue;
      atoms.push({t,x:r.left+r.width/2,y:r.top+r.height/2,r,p});
    }
    const lhAtoms=atoms.filter(a=>Math.abs(a.x-lh.x)<Math.max(70, (cols[1]?cols[1].x-lh.x:150)*.45) && !/^[-—]+$/.test(a.t));
    const anchors=[];
    for(const a of lhAtoms){ if(!anchors.some(y=>Math.abs(y-a.y)<18))anchors.push(a.y); }
    anchors.sort((a,b)=>a-b);
    if(!anchors.length)return [];
    const result=[];
    for(const ay of anchors){
      const band=atoms.filter(a=>Math.abs(a.y-ay)<=34);
      const o={};
      for(const a of band){
        let best=null,bd=Infinity;
        for(const c of cols){const d=Math.abs(a.x-c.x);if(d<bd){bd=d;best=c;}}
        if(!best||bd>120)continue;
        o[best.key]=(o[best.key]?o[best.key]+'\n':'')+a.t;
      }
      const row=finish(o); if(row.numeroLH||row.nomeViagem)result.push(row);
    }
    return dedupe(result);
  }

  // Strategy 3: reconstruct from the visible page's text + line structure.
  function rowsFromText(){
    const text=document.body?.innerText||''; if(!text)return [];
    const lines=text.split(/\n+/).map(clean).filter(Boolean);
    const lhRe=/^LT[A-Z0-9]{6,}$/i;
    const starts=[]; lines.forEach((l,i)=>{if(lhRe.test(l.replace(/\s+/g,'')))starts.push(i);});
    if(starts.length<1)return [];
    const out=[];
    for(let s=0;s<starts.length;s++){
      const a=starts[s],b=starts[s+1]??Math.min(lines.length,a+35),chunk=lines.slice(a,b);
      if(chunk.length<2)continue;
      const o={numeroLH:chunk[0]||''};
      // The screenshot shows the first columns in this stable order.
      const keys=['nomeViagem','ultimaAtualizacaoLocalizacao','station','indicadorPontualidade','veiculo','combinedSTA','combinedATA','combinedETA','destino','doca'];
      let k=0;
      for(const line of chunk.slice(1)){ if(k>=keys.length)break; if(line==='-'||line==='—'||/^\d+\/\d+$/.test(line)){/* still a valid cell */} o[keys[k++]]=(o[keys[k-1]]?o[keys[k-1]]+' / ':'')+line; }
      const row=finish(o); if(row.numeroLH)out.push(row);
    }
    return dedupe(out);
  }

  function dedupe(rows){
    const map=new Map();
    for(const r of rows){const x=normalize(r);if(!x.numeroLH&&!x.nomeViagem)continue;const key=norm(x.numeroLH)||norm(x.nomeViagem);if(!map.has(key))map.set(key,x);else{const old=map.get(key);for(const k of desiredKeys)if(!old[k]&&x[k])old[k]=x[k];}}
    return [...map.values()];
  }

  function collect(){
    const strategies=[rowsFromKnownGrids,rowsFromGeometry,rowsFromText];
    let best=[];
    for(const s of strategies){try{const got=s();if(got.length>best.length)best=got;if(best.length>=1)break;}catch(e){console.warn('[Shipping Azul] capturador:',e);}}
    return dedupe(best);
  }

  async function send(){
    const trips=collect();
    try{
      const r=await fetch(ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({trips,capturedAt:new Date().toISOString(),url:location.href,title:document.title})});
      if(!r.ok)throw new Error('HTTP '+r.status);
      console.log('[Shipping Azul] SPX V4 sincronizado:',trips.length);
      if(!trips.length){
        fetch(DEBUG_ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:location.href,title:document.title,bodyText:(document.body?.innerText||'').slice(0,12000)})}).catch(()=>{});
      }
    }catch(e){console.warn('[Shipping Azul] Bridge offline:',e.message);}
  }

  window.__shippingAzulCaptureSPX=send;
  chrome.runtime.onMessage?.addListener(msg=>{if(msg?.type==='SPX_CAPTURE')send();});
  const run=()=>setTimeout(send,1200);
  run(); setTimeout(send,4000); setTimeout(send,8000); setTimeout(send,15000); setTimeout(send,25000);
  const mo=new MutationObserver(()=>{clearTimeout(window.__spxDebounce);window.__spxDebounce=setTimeout(send,1500);});
  mo.observe(document.body,{subtree:true,childList:true,characterData:true});
})();
